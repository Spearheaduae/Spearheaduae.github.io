<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8" />
	
				<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
		
            
                        <link rel="shortcut icon" type="image/x-icon" href="http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent.png">
            <link rel="apple-touch-icon" href="http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent.png"/>
        
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="http://spearheadproperties.local/xmlrpc.php" />

	<title>SpearHead Properties | </title>
<meta name='robots' content='max-image-preview:large' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="SpearHead Properties &raquo; Feed" href="http://spearheadproperties.local/feed/" />
<link rel="alternate" type="application/rss+xml" title="SpearHead Properties &raquo; Comments Feed" href="http://spearheadproperties.local/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/spearheadproperties.local\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.2"}};
/*! This file is auto-generated */
!function(s,n){var o,i,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),a=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===a[t]})}function u(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);for(var n=e.getImageData(16,16,1,1),a=0;a<n.data.length;a++)if(0!==n.data[a])return!1;return!0}function f(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\udedf")}return!1}function g(e,t,n,a){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):s.createElement("canvas"),o=r.getContext("2d",{willReadFrequently:!0}),i=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(function(e){i[e]=t(o,e,n,a)}),i}function t(e){var t=s.createElement("script");t.src=e,t.defer=!0,s.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",i=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){s.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+g.toString()+"("+[JSON.stringify(i),f.toString(),p.toString(),u.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"}),r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=function(e){c(n=e.data),r.terminate(),t(n)})}catch(e){}c(n=g(i,f,p,u))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='layerslider-css' href='http://spearheadproperties.local/wp-content/plugins/LayerSlider/assets/static/layerslider/css/layerslider.css?ver=6.11.5' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='http://spearheadproperties.local/wp-includes/css/dist/block-library/style.min.css?ver=6.8.2' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='chaty-css-css' href='http://spearheadproperties.local/wp-content/plugins/chaty-pro/css/chaty-front.min.css?ver=3.3.21756708733' type='text/css' media='all' />
<link rel='stylesheet' id='sr7css-css' href='//spearheadproperties.local/wp-content/plugins/revslider/public/css/sr7.css?ver=6.7.35' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css' href='http://spearheadproperties.local/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.17' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='http://spearheadproperties.local/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-default-style-css' href='http://spearheadproperties.local/wp-content/themes/bridge/style.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-font_awesome-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/font-awesome/css/font-awesome.min.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-font_elegant-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/elegant-icons/style.min.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-linea_icons-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/linea-icons/style.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-dripicons-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/dripicons/dripicons.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-kiko-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/kiko/kiko-all.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-font_awesome_5-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/font-awesome-5/css/font-awesome-5.min.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-stylesheet-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/stylesheet.min.css?ver=6.8.2' type='text/css' media='all' />
<style id='bridge-stylesheet-inline-css' type='text/css'>
   .error404.disabled_footer_top .footer_top_holder, .error404.disabled_footer_bottom .footer_bottom_holder { display: none;}


</style>
<link rel='stylesheet' id='bridge-print-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/print.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-style-dynamic-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/style_dynamic.css?ver=1756708981' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-responsive-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/responsive.min.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-style-dynamic-responsive-css' href='http://spearheadproperties.local/wp-content/themes/bridge/css/style_dynamic_responsive.css?ver=1756708981' type='text/css' media='all' />
<style id='bridge-style-dynamic-responsive-inline-css' type='text/css'>
.testimonials_c_holder .testimonial_content_inner {
    padding: 3px 45px;
    background: none;
}

nav.main_menu>ul>li>a:hover>span:first-of-type:before,
nav.main_menu>ul>li.active>a>span:first-of-type:before{
opacity: 1;
}


header:not(.with_hover_bg_color) nav.main_menu>ul>li:hover>a {
opacity: 1;
}
.page_not_found {
    margin: 145px 12% 0px;
    padding-bottom: 132px;
}

.separator.transparent.center {
    margin: 0px 0;
}


.header_bottom {
padding: 0 50px;
}

header .header_inner_left {
left: 50px;
}

nav.main_menu.left {
margin-left: 23px;
}

.side_menu_button>a.search_button {
position: relative;
top: -9px;
}

.side_menu_button a:last-child {
    top: 2px;
}

.header_top {
height: 41px;
line-height: 41px;
padding: 0 35px;
}

.header_top p {
line-height: 41px;
padding: 0 15px;
}

.testimonials_c_holder .testimonial_content_inner .testimonial_text_inner .testimonial_author {
margin-top: 33px;
color: #c3c3c3 !important;
}

.testimonial_author span {
display: block;
line-height: 22px;
}

.content {
margin-top: -142px;
}

@media only screen and (max-width: 480px) {
.testimonials_c_holder .testimonial_content_inner {
padding: 3px 0;
}
}

@media only screen and (max-width: 1000px) {
.header_inner .header_inner_right {
display: none;
}
}

.side_menu .side_menu_title h4, .side_menu h5, .side_menu h6 {
    font-family: Cormorant;
    text-transform: uppercase;
    margin: 0 0 27px;
}


.header_top .textwidget a,
.header_top .textwidget p {
transition: color 0.3s ease-in-out;
}

.header_top .right p:hover {
color: #908f8f !important;
}
.footer_inner a {
transition: color 0.3s ease-in-out !important;
}

.qode_video_box .qode_video_image .qode_video_box_button_holder {
transform: translate(-51%,-50%);
-webkit-transform: translate(-51%,-50%);
}

.qode_video_box .qode_video_image .qode_video_box_button_arrow {
border: none;
display: block;
transform: translate(-48%,-48%);
-webkit-transform: translate(-48%,-48%);
}

.qode_video_box .qode_video_image .qode_video_box_button_arrow:after {
content: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' version='1.1' x='0px' y='0px' width='140px' height='140px' viewBox='0 0 140 140' enable-background='new 0 0 140 140' xml:space='preserve'%3E%3Cg%3E%3Cpath fill='%23FFFFFF' d='M63,58.057l20,12.5l-20,12.5V58.057z M64.25,60.322v20.469l16.406-10.234L64.25,60.322z'/%3E%3C/g%3E%3C/svg%3E");
display: block;
}

.qode_video_box .qode_video_image .qode_video_box_button_arrow:after {
transition: opacity 0.3s ease-in-out;
}

.qode_video_box .qode_video_image .qode_video_box_button {
transition: border-color 0.3s ease-in-out;
}

.qode_video_box .qode_video_image:hover .qode_video_box_button_arrow:after {
opacity: 0.7;
}


.header_inner .qode_search_form_3 .qode_search_close {
right: 0;
}


@media only screen and (min-width: 1441px) {
    .footer_top .widget_media_gallery .gallery-item {
        max-width: 88px !important;
    }
}

.footer_top .widget_media_gallery .gallery-item img {
border: none !important;
}

.footer_top .widget_media_gallery .gallery-item .gallery-icon {
    overflow: hidden;
}

.footer_top .widget_media_gallery .gallery-item .gallery-icon a {
    display: block;
    width: 100%;
    height: 100%;
    font-size: 0;
    line-height: 0;
}


.footer_top .widget_media_gallery .gallery-item .gallery-icon img {
    transition: transform 0.5s ease-in-out;
    display: block;
    will-change: transorm;
}

.footer_top .widget_media_gallery .gallery-item .gallery-icon img:hover {
    transform: scale(1.1);
}

@media only screen and (max-width: 1000px){
rs-fullwidth-wrap{
margin-top: -101px;
}
}


.side_menu .widget_text:last-of-type {
position: absolute;
bottom: 0;
left: 50%;
transform: translateX(-50%);
margin-bottom: 80px;
width: 100%;
}

@media only screen and (max-width: 1440px) {
.side_menu, .side_menu_slide_from_right .side_menu {
padding: 150px 60px 60px 60px;
}
}

@media only screen and (max-width: 1366px) {
.side_menu h5, .side_menu_slide_from_right .side_menu h5 {
font-size: 26px;
letter-spacing: 5px;
}
}

@media only screen and (max-width: 1024px) {
.side_menu, .side_menu_slide_from_right .side_menu {
padding: 150px 45px 60px 45px;
}

.side_menu h5, .side_menu_slide_from_right .side_menu h5 {
font-size: 20px;
letter-spacing: 4px;
}
}


.side_menu_button .qode-side-menu-button-svg svg path,
.side_menu_button .qode-side-menu-button-svg svg>* {
stroke: transparent;
}
</style>
<link rel='stylesheet' id='js_composer_front-css' href='http://spearheadproperties.local/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-style-handle-google-fonts-css' href='http://fonts.googleapis.com/css?family=Raleway%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C300italic%2C400italic%2C700italic%7CLato%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C300italic%2C400italic%2C700italic%7CCormorant%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C300italic%2C400italic%2C700italic%7CRoboto%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C300italic%2C400italic%2C700italic&#038;subset=latin%2Clatin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-core-dashboard-style-css' href='http://spearheadproperties.local/wp-content/plugins/bridge-core/modules/core-dashboard/assets/css/core-dashboard.min.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-childstyle-css' href='http://spearheadproperties.local/wp-content/themes/bridge-child/style.css?ver=6.8.2' type='text/css' media='all' />
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="layerslider-utils-js-extra">
/* <![CDATA[ */
var LS_Meta = {"v":"6.11.5","fixGSAP":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/plugins/LayerSlider/assets/static/layerslider/js/layerslider.utils.js?ver=6.11.5" id="layerslider-utils-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/plugins/LayerSlider/assets/static/layerslider/js/layerslider.kreaturamedia.jquery.js?ver=6.11.5" id="layerslider-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/plugins/LayerSlider/assets/static/layerslider/js/layerslider.transitions.js?ver=6.11.5" id="layerslider-transitions-js"></script>
<script type="text/javascript" src="//spearheadproperties.local/wp-content/plugins/revslider/public/js/libs/tptools.js?ver=6.7.35" id="tp-tools-js" async="async" data-wp-strategy="async"></script>
<script type="text/javascript" src="//spearheadproperties.local/wp-content/plugins/revslider/public/js/sr7.js?ver=6.7.35" id="sr7-js" async="async" data-wp-strategy="async"></script>
<meta name="generator" content="Powered by LayerSlider 6.11.5 - Multi-Purpose, Responsive, Parallax, Mobile-Friendly Slider Plugin for WordPress." />
<!-- LayerSlider updates and docs at: https://layerslider.kreaturamedia.com -->
<link rel="https://api.w.org/" href="http://spearheadproperties.local/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://spearheadproperties.local/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.8.2" />
<meta name="generator" content="Elementor 3.30.2; features: e_font_icon_svg, additional_custom_breakpoints, e_element_cache; settings: css_print_method-external, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<meta name="generator" content="Powered by Slider Revolution 6.7.35 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script>
	window._tpt			??= {};
	window.SR7			??= {};
	_tpt.R				??= {};
	_tpt.R.fonts		??= {};
	_tpt.R.fonts.customFonts??= {};
	SR7.devMode			=  false;
	SR7.F 				??= {};
	SR7.G				??= {};
	SR7.LIB				??= {};
	SR7.E				??= {};
	SR7.E.gAddons		??= {};
	SR7.E.php 			??= {};
	SR7.E.nonce			= '90edb9844f';
	SR7.E.ajaxurl		= 'http://spearheadproperties.local/wp-admin/admin-ajax.php';
	SR7.E.resturl		= 'http://spearheadproperties.local/wp-json/';
	SR7.E.slug_path		= 'revslider/revslider.php';
	SR7.E.slug			= 'revslider';
	SR7.E.plugin_url	= 'http://spearheadproperties.local/wp-content/plugins/revslider/';
	SR7.E.wp_plugin_url = 'http://spearheadproperties.local/wp-content/plugins/';
	SR7.E.revision		= '6.7.35';
	SR7.E.fontBaseUrl	= '';
	SR7.G.breakPoints 	= [1240,1024,778,480];
	SR7.E.modules 		= ['module','page','slide','layer','draw','animate','srtools','canvas','defaults','carousel','navigation','media','modifiers','migration'];
	SR7.E.libs 			= ['WEBGL'];
	SR7.E.css 			= ['csslp','cssbtns','cssfilters','cssnav','cssmedia'];
	SR7.E.resources		= {};
	SR7.E.ytnc			= false;
	SR7.JSON			??= {};
/*! Slider Revolution 7.0 - Page Processor */
!function(){"use strict";window.SR7??={},window._tpt??={},SR7.version="Slider Revolution 6.7.16",_tpt.getMobileZoom=()=>_tpt.is_mobile?document.documentElement.clientWidth/window.innerWidth:1,_tpt.getWinDim=function(t){_tpt.screenHeightWithUrlBar??=window.innerHeight;let e=SR7.F?.modal?.visible&&SR7.M[SR7.F.module.getIdByAlias(SR7.F.modal.requested)];_tpt.scrollBar=window.innerWidth!==document.documentElement.clientWidth||e&&window.innerWidth!==e.c.module.clientWidth,_tpt.winW=_tpt.getMobileZoom()*window.innerWidth-(_tpt.scrollBar||"prepare"==t?_tpt.scrollBarW??_tpt.mesureScrollBar():0),_tpt.winH=_tpt.getMobileZoom()*window.innerHeight,_tpt.winWAll=document.documentElement.clientWidth},_tpt.getResponsiveLevel=function(t,e){SR7.M[e];return _tpt.closestGE(t,_tpt.winWAll)},_tpt.mesureScrollBar=function(){let t=document.createElement("div");return t.className="RSscrollbar-measure",t.style.width="100px",t.style.height="100px",t.style.overflow="scroll",t.style.position="absolute",t.style.top="-9999px",document.body.appendChild(t),_tpt.scrollBarW=t.offsetWidth-t.clientWidth,document.body.removeChild(t),_tpt.scrollBarW},_tpt.loadCSS=async function(t,e,s){return s?_tpt.R.fonts.required[e].status=1:(_tpt.R[e]??={},_tpt.R[e].status=1),new Promise(((i,n)=>{if(_tpt.isStylesheetLoaded(t))s?_tpt.R.fonts.required[e].status=2:_tpt.R[e].status=2,i();else{const o=document.createElement("link");o.rel="stylesheet";let l="text",r="css";o["type"]=l+"/"+r,o.href=t,o.onload=()=>{s?_tpt.R.fonts.required[e].status=2:_tpt.R[e].status=2,i()},o.onerror=()=>{s?_tpt.R.fonts.required[e].status=3:_tpt.R[e].status=3,n(new Error(`Failed to load CSS: ${t}`))},document.head.appendChild(o)}}))},_tpt.addContainer=function(t){const{tag:e="div",id:s,class:i,datas:n,textContent:o,iHTML:l}=t,r=document.createElement(e);if(s&&""!==s&&(r.id=s),i&&""!==i&&(r.className=i),n)for(const[t,e]of Object.entries(n))"style"==t?r.style.cssText=e:r.setAttribute(`data-${t}`,e);return o&&(r.textContent=o),l&&(r.innerHTML=l),r},_tpt.collector=function(){return{fragment:new DocumentFragment,add(t){var e=_tpt.addContainer(t);return this.fragment.appendChild(e),e},append(t){t.appendChild(this.fragment)}}},_tpt.isStylesheetLoaded=function(t){let e=t.split("?")[0];return Array.from(document.querySelectorAll('link[rel="stylesheet"], link[rel="preload"]')).some((t=>t.href.split("?")[0]===e))},_tpt.preloader={requests:new Map,preloaderTemplates:new Map,show:function(t,e){if(!e||!t)return;const{type:s,color:i}=e;if(s<0||"off"==s)return;const n=`preloader_${s}`;let o=this.preloaderTemplates.get(n);o||(o=this.build(s,i),this.preloaderTemplates.set(n,o)),this.requests.has(t)||this.requests.set(t,{count:0});const l=this.requests.get(t);clearTimeout(l.timer),l.count++,1===l.count&&(l.timer=setTimeout((()=>{l.preloaderClone=o.cloneNode(!0),l.anim&&l.anim.kill(),void 0!==_tpt.gsap?l.anim=_tpt.gsap.fromTo(l.preloaderClone,1,{opacity:0},{opacity:1}):l.preloaderClone.classList.add("sr7-fade-in"),t.appendChild(l.preloaderClone)}),150))},hide:function(t){if(!this.requests.has(t))return;const e=this.requests.get(t);e.count--,e.count<0&&(e.count=0),e.anim&&e.anim.kill(),0===e.count&&(clearTimeout(e.timer),e.preloaderClone&&(e.preloaderClone.classList.remove("sr7-fade-in"),e.anim=_tpt.gsap.to(e.preloaderClone,.3,{opacity:0,onComplete:function(){e.preloaderClone.remove()}})))},state:function(t){if(!this.requests.has(t))return!1;return this.requests.get(t).count>0},build:(t,e="#ffffff",s="")=>{if(t<0||"off"===t)return null;const i=parseInt(t);if(t="prlt"+i,isNaN(i))return null;if(_tpt.loadCSS(SR7.E.plugin_url+"public/css/preloaders/t"+i+".css","preloader_"+t),isNaN(i)||i<6){const n=`background-color:${e}`,o=1===i||2==i?n:"",l=3===i||4==i?n:"",r=_tpt.collector();["dot1","dot2","bounce1","bounce2","bounce3"].forEach((t=>r.add({tag:"div",class:t,datas:{style:l}})));const d=_tpt.addContainer({tag:"sr7-prl",class:`${t} ${s}`,datas:{style:o}});return r.append(d),d}{let n={};if(7===i){let t;e.startsWith("#")?(t=e.replace("#",""),t=`rgba(${parseInt(t.substring(0,2),16)}, ${parseInt(t.substring(2,4),16)}, ${parseInt(t.substring(4,6),16)}, `):e.startsWith("rgb")&&(t=e.slice(e.indexOf("(")+1,e.lastIndexOf(")")).split(",").map((t=>t.trim())),t=`rgba(${t[0]}, ${t[1]}, ${t[2]}, `),t&&(n.style=`border-top-color: ${t}0.65); border-bottom-color: ${t}0.15); border-left-color: ${t}0.65); border-right-color: ${t}0.15)`)}else 12===i&&(n.style=`background:${e}`);const o=[10,0,4,2,5,9,0,4,4,2][i-6],l=_tpt.collector(),r=l.add({tag:"div",class:"sr7-prl-inner",datas:n});Array.from({length:o}).forEach((()=>r.appendChild(l.add({tag:"span",datas:{style:`background:${e}`}}))));const d=_tpt.addContainer({tag:"sr7-prl",class:`${t} ${s}`});return l.append(d),d}}},SR7.preLoader={show:(t,e)=>{"off"!==(SR7.M[t]?.settings?.pLoader?.type??"off")&&_tpt.preloader.show(e||SR7.M[t].c.module,SR7.M[t]?.settings?.pLoader??{color:"#fff",type:10})},hide:(t,e)=>{"off"!==(SR7.M[t]?.settings?.pLoader?.type??"off")&&_tpt.preloader.hide(e||SR7.M[t].c.module)},state:(t,e)=>_tpt.preloader.state(e||SR7.M[t].c.module)},_tpt.prepareModuleHeight=function(t){window.SR7.M??={},window.SR7.M[t.id]??={},"ignore"==t.googleFont&&(SR7.E.ignoreGoogleFont=!0);let e=window.SR7.M[t.id];if(null==_tpt.scrollBarW&&_tpt.mesureScrollBar(),e.c??={},e.states??={},e.settings??={},e.settings.size??={},t.fixed&&(e.settings.fixed=!0),e.c.module=document.querySelector("sr7-module#"+t.id),e.c.adjuster=e.c.module.getElementsByTagName("sr7-adjuster")[0],e.c.content=e.c.module.getElementsByTagName("sr7-content")[0],"carousel"==t.type&&(e.c.carousel=e.c.content.getElementsByTagName("sr7-carousel")[0]),null==e.c.module||null==e.c.module)return;t.plType&&t.plColor&&(e.settings.pLoader={type:t.plType,color:t.plColor}),void 0===t.plType||"off"===t.plType||SR7.preLoader.state(t.id)&&SR7.preLoader.state(t.id,e.c.module)||SR7.preLoader.show(t.id,e.c.module),_tpt.winW||_tpt.getWinDim("prepare"),_tpt.getWinDim();let s=""+e.c.module.dataset?.modal;"modal"==s||"true"==s||"undefined"!==s&&"false"!==s||(e.settings.size.fullWidth=t.size.fullWidth,e.LEV??=_tpt.getResponsiveLevel(window.SR7.G.breakPoints,t.id),t.vpt=_tpt.fillArray(t.vpt,5),e.settings.vPort=t.vpt[e.LEV],void 0!==t.el&&"720"==t.el[4]&&t.gh[4]!==t.el[4]&&"960"==t.el[3]&&t.gh[3]!==t.el[3]&&"768"==t.el[2]&&t.gh[2]!==t.el[2]&&delete t.el,e.settings.size.height=null==t.el||null==t.el[e.LEV]||0==t.el[e.LEV]||"auto"==t.el[e.LEV]?_tpt.fillArray(t.gh,5,-1):_tpt.fillArray(t.el,5,-1),e.settings.size.width=_tpt.fillArray(t.gw,5,-1),e.settings.size.minHeight=_tpt.fillArray(t.mh??[0],5,-1),e.cacheSize={fullWidth:e.settings.size?.fullWidth,fullHeight:e.settings.size?.fullHeight},void 0!==t.off&&(t.off?.t&&(e.settings.size.m??={})&&(e.settings.size.m.t=t.off.t),t.off?.b&&(e.settings.size.m??={})&&(e.settings.size.m.b=t.off.b),t.off?.l&&(e.settings.size.p??={})&&(e.settings.size.p.l=t.off.l),t.off?.r&&(e.settings.size.p??={})&&(e.settings.size.p.r=t.off.r),e.offsetPrepared=!0),_tpt.updatePMHeight(t.id,t,!0))},_tpt.updatePMHeight=(t,e,s)=>{let i=SR7.M[t];var n=i.settings.size.fullWidth?_tpt.winW:i.c.module.parentNode.offsetWidth;n=0===n||isNaN(n)?_tpt.winW:n;let o=i.settings.size.width[i.LEV]||i.settings.size.width[i.LEV++]||i.settings.size.width[i.LEV--]||n,l=i.settings.size.height[i.LEV]||i.settings.size.height[i.LEV++]||i.settings.size.height[i.LEV--]||0,r=i.settings.size.minHeight[i.LEV]||i.settings.size.minHeight[i.LEV++]||i.settings.size.minHeight[i.LEV--]||0;if(l="auto"==l?0:l,l=parseInt(l),"carousel"!==e.type&&(n-=parseInt(e.onw??0)||0),i.MP=!i.settings.size.fullWidth&&n<o||_tpt.winW<o?Math.min(1,n/o):1,e.size.fullScreen||e.size.fullHeight){let t=parseInt(e.fho)||0,s=(""+e.fho).indexOf("%")>-1;e.newh=_tpt.winH-(s?_tpt.winH*t/100:t)}else e.newh=i.MP*Math.max(l,r);if(e.newh+=(parseInt(e.onh??0)||0)+(parseInt(e.carousel?.pt)||0)+(parseInt(e.carousel?.pb)||0),void 0!==e.slideduration&&(e.newh=Math.max(e.newh,parseInt(e.slideduration)/3)),e.shdw&&_tpt.buildShadow(e.id,e),i.c.adjuster.style.height=e.newh+"px",i.c.module.style.height=e.newh+"px",i.c.content.style.height=e.newh+"px",i.states.heightPrepared=!0,i.dims??={},i.dims.moduleRect=i.c.module.getBoundingClientRect(),i.c.content.style.left="-"+i.dims.moduleRect.left+"px",!i.settings.size.fullWidth)return s&&requestAnimationFrame((()=>{n!==i.c.module.parentNode.offsetWidth&&_tpt.updatePMHeight(e.id,e)})),void _tpt.bgStyle(e.id,e,window.innerWidth==_tpt.winW,!0);_tpt.bgStyle(e.id,e,window.innerWidth==_tpt.winW,!0),requestAnimationFrame((function(){s&&requestAnimationFrame((()=>{n!==i.c.module.parentNode.offsetWidth&&_tpt.updatePMHeight(e.id,e)}))})),i.earlyResizerFunction||(i.earlyResizerFunction=function(){requestAnimationFrame((function(){_tpt.getWinDim(),_tpt.moduleDefaults(e.id,e),_tpt.updateSlideBg(t,!0)}))},window.addEventListener("resize",i.earlyResizerFunction))},_tpt.buildShadow=function(t,e){let s=SR7.M[t];null==s.c.shadow&&(s.c.shadow=document.createElement("sr7-module-shadow"),s.c.shadow.classList.add("sr7-shdw-"+e.shdw),s.c.content.appendChild(s.c.shadow))},_tpt.bgStyle=async(t,e,s,i,n)=>{const o=SR7.M[t];if((e=e??o.settings).fixed&&!o.c.module.classList.contains("sr7-top-fixed")&&(o.c.module.classList.add("sr7-top-fixed"),o.c.module.style.position="fixed",o.c.module.style.width="100%",o.c.module.style.top="0px",o.c.module.style.left="0px",o.c.module.style.pointerEvents="none",o.c.module.style.zIndex=5e3,o.c.content.style.pointerEvents="none"),null==o.c.bgcanvas){let t=document.createElement("sr7-module-bg"),l=!1;if("string"==typeof e?.bg?.color&&e?.bg?.color.includes("{"))if(_tpt.gradient&&_tpt.gsap)e.bg.color=_tpt.gradient.convert(e.bg.color);else try{let t=JSON.parse(e.bg.color);(t?.orig||t?.string)&&(e.bg.color=JSON.parse(e.bg.color))}catch(t){return}let r="string"==typeof e?.bg?.color?e?.bg?.color||"transparent":e?.bg?.color?.string??e?.bg?.color?.orig??e?.bg?.color?.color??"transparent";if(t.style["background"+(String(r).includes("grad")?"":"Color")]=r,("transparent"!==r||n)&&(l=!0),o.offsetPrepared&&(t.style.visibility="hidden"),e?.bg?.image?.src&&(t.style.backgroundImage=`url(${e?.bg?.image.src})`,t.style.backgroundSize=""==(e.bg.image?.size??"")?"cover":e.bg.image.size,t.style.backgroundPosition=e.bg.image.position,t.style.backgroundRepeat=""==e.bg.image.repeat||null==e.bg.image.repeat?"no-repeat":e.bg.image.repeat,l=!0),!l)return;o.c.bgcanvas=t,e.size.fullWidth?t.style.width=_tpt.winW-(s&&_tpt.winH<document.body.offsetHeight?_tpt.scrollBarW:0)+"px":i&&(t.style.width=o.c.module.offsetWidth+"px"),e.sbt?.use?o.c.content.appendChild(o.c.bgcanvas):o.c.module.appendChild(o.c.bgcanvas)}o.c.bgcanvas.style.height=void 0!==e.newh?e.newh+"px":("carousel"==e.type?o.dims.module.h:o.dims.content.h)+"px",o.c.bgcanvas.style.left=!s&&e.sbt?.use||o.c.bgcanvas.closest("SR7-CONTENT")?"0px":"-"+(o?.dims?.moduleRect?.left??0)+"px"},_tpt.updateSlideBg=function(t,e){const s=SR7.M[t];let i=s.settings;s?.c?.bgcanvas&&(i.size.fullWidth?s.c.bgcanvas.style.width=_tpt.winW-(e&&_tpt.winH<document.body.offsetHeight?_tpt.scrollBarW:0)+"px":preparing&&(s.c.bgcanvas.style.width=s.c.module.offsetWidth+"px"))},_tpt.moduleDefaults=(t,e)=>{let s=SR7.M[t];null!=s&&null!=s.c&&null!=s.c.module&&(s.dims??={},s.dims.moduleRect=s.c.module.getBoundingClientRect(),s.c.content.style.left="-"+s.dims.moduleRect.left+"px",s.c.content.style.width=_tpt.winW-_tpt.scrollBarW+"px","carousel"==e.type&&(s.c.module.style.overflow="visible"),_tpt.bgStyle(t,e,window.innerWidth==_tpt.winW))},_tpt.getOffset=t=>{var e=t.getBoundingClientRect(),s=window.pageXOffset||document.documentElement.scrollLeft,i=window.pageYOffset||document.documentElement.scrollTop;return{top:e.top+i,left:e.left+s}},_tpt.fillArray=function(t,e){let s,i;t=Array.isArray(t)?t:[t];let n=Array(e),o=t.length;for(i=0;i<t.length;i++)n[i+(e-o)]=t[i],null==s&&"#"!==t[i]&&(s=t[i]);for(let t=0;t<e;t++)void 0!==n[t]&&"#"!=n[t]||(n[t]=s),s=n[t];return n},_tpt.closestGE=function(t,e){let s=Number.MAX_VALUE,i=-1;for(let n=0;n<t.length;n++)t[n]-1>=e&&t[n]-1-e<s&&(s=t[n]-1-e,i=n);return++i}}();</script>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body class="error404 wp-theme-bridge wp-child-theme-bridge-child bridge-core-2.6.8  qode-page-loading-effect-enabled qode-title-hidden qode_grid_1300 footer_responsive_adv hide_top_bar_on_mobile_header qode_disabled_responsive_button_padding_change qode-child-theme-ver-1.0.0 qode-theme-ver-25.3 qode-theme-bridge wpb-js-composer js-comp-ver-6.6.0 vc_responsive elementor-default elementor-kit-5" itemscope itemtype="http://schema.org/WebPage">



		<div class="qode-page-loading-effect-holder">
		<div class="ajax_loader"><div class="ajax_loader_1"><div class="rotating_cubes"><div class="cube1"></div><div class="cube2"></div></div></div></div>
			</div>
	
<div class="wrapper">
	<div class="wrapper_inner">

    
		<!-- Google Analytics start -->
				<!-- Google Analytics end -->

		
	<header class=" has_top centered_logo_animate scroll_header_top_area  regular transparent menu_position_left page_header">
    <div class="header_inner clearfix">
                <div class="header_top_bottom_holder">
            	<div class="header_top clearfix" style='background-color:rgba(0, 186, 0, 0);' >
							<div class="left">
						<div class="inner">
							<div class="header-widget widget_text header-left-widget">			<div class="textwidget"><p>Visit Us: Flat no:413, Al nasiriya building ( rashed lootha building), Al Qusais Industrial Area 1, Damascus street, Al Qusais, Dubai</p>
</div>
		</div>						</div>
					</div>
					<div class="right">
						<div class="inner">
							<div class="header-widget widget_text header-right-widget">			<div class="textwidget"><p><a href="tel:+971 50 104 7667">+971 50 104 7667</a> &#8211; <a href="mailto:Info@spearheaduae.com?subject=Hello%20Spearhead%20Properties&amp;body=I'm%20interested%20in%20learning%20more.%20When%20can%20we%20connect"> Email </a>&#8211; <a href="https://www.linkedin.com/in/spearhead-properties-uae-4504a5352/" target="_blank" rel="noopener">LinkedIn</a> &#8211; <a href="https://www.instagram.com/spearheadrealestateuae/profilecard/" target="_blank" rel="noopener">Instagram</a></p>
</div>
		</div>						</div>
					</div>
						</div>

            <div class="header_bottom clearfix" style=' background-color:rgba(255, 255, 255, 0);' >
                
                            <div class="header_inner_left">
                                									<div class="mobile_menu_button">
		<span>
			<i class="qode_icon_font_awesome fa fa-bars " ></i>		</span>
	</div>
                                <div class="logo_wrapper" >
	<div class="q_logo">
		<a itemprop="url" href="http://spearheadproperties.local/" >
             <img itemprop="image" class="normal" src="http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent.png" alt="Logo"> 			 <img itemprop="image" class="light" src="http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent.png" alt="Logo"/> 			 <img itemprop="image" class="dark" src="http://spearheadproperties.local/wp-content/uploads/2025/08/SpearHead-Logo-Black-Transparent.png" alt="Logo"/> 			 <img itemprop="image" class="sticky" src="http://spearheadproperties.local/wp-content/uploads/2025/08/SpearHead-Logo-Black-Transparent.png" alt="Logo"/> 			 <img itemprop="image" class="mobile" src="http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent.png" alt="Logo"/> 					</a>
	</div>
	</div>                                                            </div>
                                                                    <div class="header_inner_right">
                                        <div class="side_menu_button_wrapper right">
                                                                                                                                    <div class="side_menu_button">
                                                                                                                                                
                                            </div>
                                        </div>
                                    </div>
                                
                                
                                <nav class="main_menu drop_down left">
                                    <ul id="menu-menu" class=""><li id="nav-menu-item-214" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home  narrow"><a href="http://spearheadproperties.local/" class=""><i class="menu_icon blank fa"></i><span>Home<span class="underline_dash"></span></span><span class="plus"></span></a></li>
<li id="nav-menu-item-553" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://spearheadproperties.local/contact/" class=""><i class="menu_icon blank fa"></i><span>Contact<span class="underline_dash"></span></span><span class="plus"></span></a></li>
<li id="nav-menu-item-749" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://spearheadproperties.local/tools/" class=""><i class="menu_icon blank fa"></i><span>Real Estate Tools<span class="underline_dash"></span></span><span class="plus"></span></a></li>
<li id="nav-menu-item-344" class="menu-item menu-item-type-custom menu-item-object-custom  wide right_position"><a href="https://calendly.com/mwadhwani59/30min" class=""><i class="menu_icon icon-basic-calendar fa"></i><span>Schedule a Meeting<span class="underline_dash"></span></span><span class="plus"></span></a></li>
</ul>                                </nav>
                                							    <nav class="mobile_menu">
	<ul id="menu-menu-1" class=""><li id="mobile-menu-item-214" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="http://spearheadproperties.local/" class=""><span>Home</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-553" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://spearheadproperties.local/contact/" class=""><span>Contact</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-749" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://spearheadproperties.local/tools/" class=""><span>Real Estate Tools</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-344" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://calendly.com/mwadhwani59/30min" class=""><span>Schedule a Meeting</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
</ul></nav>                                                </div>
            </div>
        </div>
</header>	<a id="back_to_top" href="#">
        <span class="fa-stack">
            <span aria-hidden="true" class="qode_icon_font_elegant arrow_carrot-up " ></span>        </span>
	</a>
	
	
    
    	
    
    <div class="content ">
        <div class="content_inner  ">
    
						<div class="container">
                				<div class="container_inner default_template_holder">
					<div class="page_not_found">
						<h2> The page you are looking for is not found </h2>
                        <p> The page you are looking for does not exist. It may have been moved, or removed altogether. Perhaps you can return back to the site&#039;s homepage and see if you can find what you are looking for. </p>
						<div class="separator  transparent center  " style="margin-top:35px;"></div>
						<p><a itemprop="url" class="qbutton with-shadow" href="http://spearheadproperties.local/"> Back to homepage </a></p>
						<div class="separator  transparent center  " style="margin-top:35px;"></div>
					</div>
				</div>
                			</div>
		
	</div>
</div>



	<footer class="uncover">
		<div class="footer_inner clearfix">
				<div class="footer_top_holder">
            			<div class="footer_top">
								<div class="container">
					<div class="container_inner">
																	<div class="four_columns clearfix">
								<div class="column1 footer_col1">
									<div class="column_inner">
										<div id="block-7" class="widget widget_block widget_media_image">
<figure class="wp-block-image size-full"><img fetchpriority="high" fetchpriority="high" decoding="async" width="1024" height="1024" src="http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent.png" alt="" class="wp-image-231" srcset="http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent.png 1024w, http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent-300x300.png 300w, http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent-150x150.png 150w, http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent-768x768.png 768w, http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent-570x570.png 570w, http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent-500x500.png 500w, http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent-1000x1000.png 1000w, http://spearheadproperties.local/wp-content/uploads/2025/08/Spearhead-logo-transparent-700x700.png 700w" sizes="(max-width: 1024px) 100vw, 1024px" /></figure>
</div><div class="widget qode_separator_widget" style="margin-bottom: 17px;"></div>									</div>
								</div>
								<div class="column2 footer_col2">
									<div class="column_inner">
										<div class="widget qode_separator_widget" style="margin-bottom: 23px;"></div><div id="nav_menu-4" class="widget widget_nav_menu"><h5>Links</h5><div class="menu-menu-container"><ul id="menu-menu-2" class="menu"><li id="menu-item-214" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-214"><a href="http://spearheadproperties.local/">Home</a></li>
<li id="menu-item-553" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-553"><a href="http://spearheadproperties.local/contact/">Contact</a></li>
<li id="menu-item-749" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-749"><a href="http://spearheadproperties.local/tools/">Real Estate Tools</a></li>
<li id="menu-item-344" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-344"><a href="https://calendly.com/mwadhwani59/30min">Schedule a Meeting</a></li>
</ul></div></div><div class="widget qode_separator_widget" style="margin-bottom: 34px;"></div>									</div>
								</div>
								<div class="column3 footer_col3">
									<div class="column_inner">
										<div class="widget qode_separator_widget" style="margin-bottom: 20px;"></div>									</div>
								</div>
								<div class="column4 footer_col4">
									<div class="column_inner">
										<div class="widget qode_separator_widget" style="margin-bottom: 23px;"></div><div id="block-8" class="widget widget_block">
<h3 class="wp-block-heading">Follow us on</h3>
</div><span class='q_social_icon_holder square_social' data-color=black data-hover-background-color=orange data-hover-color=black><a itemprop='url' href='https://www.linkedin.com/in/spearhead-properties-uae-4504a5352/' target='_blank'><span class='fa-stack ' style='background-color: white;'><i class="qode_icon_font_awesome fa fa-linkedin " style="color: black;" ></i></span></a></span><span class='q_social_icon_holder square_social' data-color=black data-hover-background-color=orange data-hover-color=black><a itemprop='url' href='https://www.instagram.com/spearheadrealestateuae/profilecard/' target='_blank'><span class='fa-stack ' style='background-color: white;'><i class="qode_icon_font_awesome fa fa-instagram " style="color: black;" ></i></span></a></span><div class="widget qode_separator_widget" style="margin-bottom: 34px;"></div>									</div>
								</div>
							</div>
															</div>
				</div>
							</div>
					</div>
							<div class="footer_bottom_holder">
                                    <div style="background-color: rgba( 255, 255, 255, 0.15);height: 1px" class="footer_bottom_border "></div>
                								<div class="container">
					<div class="container_inner">
										<div class="two_columns_50_50 footer_bottom_columns clearfix">
					<div class="column1 footer_bottom_column">
						<div class="column_inner">
							<div class="footer_bottom">
								
<div class="wp-block-media-text is-stacked-on-mobile"><figure class="wp-block-media-text__media"></figure><div class="wp-block-media-text__content">
<p>Designed and Maintained by Murtuza Boriwala</p>
</div></div>
							</div>
						</div>
					</div>
					<div class="column2 footer_bottom_column">
						<div class="column_inner">
							<div class="footer_bottom">
											<div class="textwidget"><p><a href="tel:+971 50 104 7667">+971 50 104 7667</a> &#8211; <a href="mailto:Info@spearheaduae.com?subject=Hello%20Spearhead%20Properties&amp;body=I'm%20interested%20in%20learning%20more.%20When%20can%20we%20connect"> Email </a>&#8211; <a href="https://www.linkedin.com/in/spearhead-properties-uae-4504a5352/" target="_blank" rel="noopener">LinkedIn</a> &#8211; <a href="https://www.instagram.com/spearheadrealestateuae/profilecard/" target="_blank" rel="noopener">Instagram</a></p>
</div>
									</div>
						</div>
					</div>
				</div>
											</div>
			</div>
						</div>
				</div>
	</footer>
		
</div>
</div>
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/bridge-child\/*","\/wp-content\/themes\/bridge\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<script type="text/javascript" id="chaty-js-extra">
/* <![CDATA[ */
var chaty_settings = {"chaty_widgets":[{"id":0,"identifier":0,"settings":{"cta_type":"simple-view","cta_body":"","cta_head":"","cta_head_bg_color":"","cta_head_text_color":"","show_close_button":"yes","position":"right","custom_position":1,"bottom_spacing":"25","side_spacing":"25","icon_view":"vertical","default_state":"click","cta_text":"Let's talk","cta_text_color":"#333333","cta_bg_color":"#ffffff","show_cta":"first_click","is_pending_mesg_enabled":"on","pending_mesg_count":"1","pending_mesg_count_color":"#ffffff","pending_mesg_count_bgcolor":"#dd0000","widget_icon":"chat-smile","widget_icon_url":"","widget_fa_icon":"","font_family":"Helvetica","widget_size":"70","custom_widget_size":"70","is_google_analytics_enabled":"1","bg_blur_effect":"1","close_text":"Hide","widget_color":"rgb(255, 255, 255)","widget_icon_color":"#202020","widget_rgb_color":"255,255,255","has_custom_css":0,"custom_css":"","widget_token":"c4d17440a9","widget_index":"","attention_effect":"shockwave"},"triggers":{"has_time_delay":1,"time_delay":"85","exit_intent":1,"has_display_after_page_scroll":1,"display_after_page_scroll":"40","auto_hide_widget":0,"hide_after":0,"show_on_pages_rules":[],"time_diff":0,"has_date_scheduling_rules":0,"date_scheduling_rules":{"start_date_time":"","end_date_time":""},"date_scheduling_rules_timezone":0,"day_hours_scheduling_rules_timezone":0,"has_day_hours_scheduling_rules":0,"day_hours_scheduling_rules":[],"day_time_diff":"","show_on_direct_visit":0,"show_on_referrer_social_network":0,"show_on_referrer_search_engines":0,"show_on_referrer_google_ads":0,"show_on_referrer_urls":[],"has_show_on_specific_referrer_urls":0,"has_traffic_source":0,"has_countries":0,"countries":[],"has_target_rules":0},"channels":[{"channel":"Phone","value":"+971501047667","hover_text":"Phone","chatway_position":"","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#03E78B\"\/><path d=\"M19.3929 14.9176C17.752 14.7684 16.2602 14.3209 14.7684 13.7242C14.0226 13.4259 13.1275 13.7242 12.8292 14.4701L11.7849 16.2602C8.65222 14.6193 6.11623 11.9341 4.47529 8.95057L6.41458 7.90634C7.16046 7.60799 7.45881 6.71293 7.16046 5.96705C6.56375 4.47529 6.11623 2.83435 5.96705 1.34259C5.96705 0.596704 5.22117 0 4.47529 0H0.745882C0.298353 0 5.69062e-07 0.298352 5.69062e-07 0.745881C5.69062e-07 3.72941 0.596704 6.71293 1.93929 9.3981C3.87858 13.575 7.30964 16.8569 11.3374 18.7962C14.0226 20.1388 17.0061 20.7355 19.9896 20.7355C20.4371 20.7355 20.7355 20.4371 20.7355 19.9896V16.4094C20.7355 15.5143 20.1388 14.9176 19.3929 14.9176Z\" transform=\"translate(9.07179 9.07178)\" fill=\"white\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"#202020","icon_rgb_color":"32,32,32","channel_type":"Phone","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"","wp_popup_headline":"","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"tel:+971501047667","mobile_target":"","desktop_target":"","target":"","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"c4d17440a9","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""},{"channel":"Whatsapp","value":"971501047667","hover_text":"WhatsApp","chatway_position":"","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#49E670\"\/><path d=\"M12.9821 10.1115C12.7029 10.7767 11.5862 11.442 10.7486 11.575C10.1902 11.7081 9.35269 11.8411 6.84003 10.7767C3.48981 9.44628 1.39593 6.25317 1.25634 6.12012C1.11674 5.85403 2.13001e-06 4.39053 2.13001e-06 2.92702C2.13001e-06 1.46351 0.83755 0.665231 1.11673 0.399139C1.39592 0.133046 1.8147 1.01506e-06 2.23348 1.01506e-06C2.37307 1.01506e-06 2.51267 1.01506e-06 2.65226 1.01506e-06C2.93144 1.01506e-06 3.21063 -2.02219e-06 3.35022 0.532183C3.62941 1.19741 4.32736 2.66092 4.32736 2.79397C4.46696 2.92702 4.46696 3.19311 4.32736 3.32616C4.18777 3.59225 4.18777 3.59224 3.90858 3.85834C3.76899 3.99138 3.6294 4.12443 3.48981 4.39052C3.35022 4.52357 3.21063 4.78966 3.35022 5.05576C3.48981 5.32185 4.18777 6.38622 5.16491 7.18449C6.42125 8.24886 7.39839 8.51496 7.81717 8.78105C8.09636 8.91409 8.37554 8.9141 8.65472 8.648C8.93391 8.38191 9.21309 7.98277 9.49228 7.58363C9.77146 7.31754 10.0507 7.1845 10.3298 7.31754C10.609 7.45059 12.2841 8.11582 12.5633 8.38191C12.8425 8.51496 13.1217 8.648 13.1217 8.78105C13.1217 8.78105 13.1217 9.44628 12.9821 10.1115Z\" transform=\"translate(12.9597 12.9597)\" fill=\"#FAFAFA\"\/><path d=\"M0.196998 23.295L0.131434 23.4862L0.323216 23.4223L5.52771 21.6875C7.4273 22.8471 9.47325 23.4274 11.6637 23.4274C18.134 23.4274 23.4274 18.134 23.4274 11.6637C23.4274 5.19344 18.134 -0.1 11.6637 -0.1C5.19344 -0.1 -0.1 5.19344 -0.1 11.6637C-0.1 13.9996 0.624492 16.3352 1.93021 18.2398L0.196998 23.295ZM5.87658 19.8847L5.84025 19.8665L5.80154 19.8788L2.78138 20.8398L3.73978 17.9646L3.75932 17.906L3.71562 17.8623L3.43104 17.5777C2.27704 15.8437 1.55796 13.8245 1.55796 11.6637C1.55796 6.03288 6.03288 1.55796 11.6637 1.55796C17.2945 1.55796 21.7695 6.03288 21.7695 11.6637C21.7695 17.2945 17.2945 21.7695 11.6637 21.7695C9.64222 21.7695 7.76778 21.1921 6.18227 20.039L6.17557 20.0342L6.16817 20.0305L5.87658 19.8847Z\" transform=\"translate(7.7758 7.77582)\" fill=\"white\" stroke=\"white\" stroke-width=\"0.2\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"#202020","icon_rgb_color":"32,32,32","channel_type":"Whatsapp","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"1","has_welcome_message":"1","emoji_picker":"1","input_placeholder":"How are you doing today?","chat_welcome_message":"<p>How can I help you? :)<\/p>","wp_popup_headline":"Let&#039;s chat on WhatsApp","wp_popup_nickname":"Mayur","wp_popup_profile":"http:\/\/spearheadproperties.local\/wp-content\/uploads\/2025\/08\/Mayur-Profile-Image.png","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"https:\/\/web.whatsapp.com\/send?phone=971501047667","mobile_target":"","desktop_target":"_blank","target":"_blank","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"c4d17440a9","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""},{"channel":"Email","value":"Info@spearheaduae.com","hover_text":"Email","chatway_position":"","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#FF485F\"\/><path d=\"M20.5379 14.2557H1.36919C0.547677 14.2557 0 13.7373 0 12.9597V1.29597C0 0.518387 0.547677 0 1.36919 0H20.5379C21.3594 0 21.9071 0.518387 21.9071 1.29597V12.9597C21.9071 13.7373 21.3594 14.2557 20.5379 14.2557ZM20.5379 12.9597V13.6077V12.9597ZM1.36919 1.29597V12.9597H20.5379V1.29597H1.36919Z\" transform=\"translate(8.48619 12.3117)\" fill=\"white\"\/><path d=\"M10.9659 8.43548C10.829 8.43548 10.692 8.43548 10.5551 8.30588L0.286184 1.17806C0.012346 0.918864 -0.124573 0.530073 0.149265 0.270879C0.423104 0.0116857 0.833862 -0.117911 1.1077 0.141283L10.9659 7.00991L20.8241 0.141283C21.0979 -0.117911 21.5087 0.0116857 21.7825 0.270879C22.0563 0.530073 21.9194 0.918864 21.6456 1.17806L11.3766 8.30588C11.2397 8.43548 11.1028 8.43548 10.9659 8.43548Z\" transform=\"translate(8.47443 12.9478)\" fill=\"white\"\/><path d=\"M9.0906 7.13951C8.95368 7.13951 8.81676 7.13951 8.67984 7.00991L0.327768 1.17806C-0.0829894 0.918864 -0.0829899 0.530073 0.190849 0.270879C0.327768 0.0116855 0.738525 -0.117911 1.14928 0.141282L9.50136 5.97314C9.7752 6.23233 9.91212 6.62112 9.63828 6.88032C9.50136 7.00991 9.36444 7.13951 9.0906 7.13951Z\" transform=\"translate(20.6183 18.7799)\" fill=\"white\"\/><path d=\"M0.696942 7.13951C0.423104 7.13951 0.286185 7.00991 0.149265 6.88032C-0.124573 6.62112 0.012346 6.23233 0.286185 5.97314L8.63826 0.141282C9.04902 -0.117911 9.45977 0.0116855 9.59669 0.270879C9.87053 0.530073 9.73361 0.918864 9.45977 1.17806L1.1077 7.00991C0.970781 7.13951 0.833862 7.13951 0.696942 7.13951Z\" transform=\"translate(8.47443 18.7799)\" fill=\"white\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"#202020","icon_rgb_color":"32,32,32","channel_type":"Email","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"","wp_popup_headline":"","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"mailto:Info@spearheaduae.com","mobile_target":"","desktop_target":"","target":"","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"c4d17440a9","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""},{"channel":"Instagram","value":"https:\/\/www.instagram.com\/spearheadrealestateuae\/profilecard\/","hover_text":"Instagram","chatway_position":"","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.5\" cy=\"19.5\" r=\"19.5\" fill=\"url(#linear-gradient)\"\/><path id=\"Path_1923\" data-name=\"Path 1923\" d=\"M13.177,0H5.022A5.028,5.028,0,0,0,0,5.022v8.155A5.028,5.028,0,0,0,5.022,18.2h8.155A5.028,5.028,0,0,0,18.2,13.177V5.022A5.028,5.028,0,0,0,13.177,0Zm3.408,13.177a3.412,3.412,0,0,1-3.408,3.408H5.022a3.411,3.411,0,0,1-3.408-3.408V5.022A3.412,3.412,0,0,1,5.022,1.615h8.155a3.412,3.412,0,0,1,3.408,3.408v8.155Z\" transform=\"translate(10 10.4)\" fill=\"#fff\"\/><path id=\"Path_1924\" data-name=\"Path 1924\" d=\"M45.658,40.97a4.689,4.689,0,1,0,4.69,4.69A4.695,4.695,0,0,0,45.658,40.97Zm0,7.764a3.075,3.075,0,1,1,3.075-3.075A3.078,3.078,0,0,1,45.658,48.734Z\" transform=\"translate(-26.558 -26.159)\" fill=\"#fff\"\/><\/svg><path id=\"Path_1925\" data-name=\"Path 1925\" d=\"M120.105,28.251a1.183,1.183,0,1,0,.838.347A1.189,1.189,0,0,0,120.105,28.251Z\" transform=\"translate(-96.119 -14.809)\" fill=\"#fff\"\/>","is_desktop":1,"is_mobile":1,"icon_color":"#202020","icon_rgb_color":"32,32,32","channel_type":"Instagram","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"","wp_popup_headline":"","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"https:\/\/www.instagram.com\/https:\/\/www.instagram.com\/spearheadrealestateuae\/profilecard\/","mobile_target":"_blank","desktop_target":"_blank","target":"_blank","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"c4d17440a9","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""},{"channel":"SMS","value":"+971501047667","hover_text":"SMS","chatway_position":"","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#FF549C\"\/><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M2.60298 0H16.9194C18.351 0 19.5224 1.19321 19.5224 2.65158V14.5838C19.5224 16.0421 18.351 17.2354 16.9194 17.2354H7.4185L3.64418 20.4173C3.51402 20.5499 3.38388 20.5499 3.25372 20.5499H2.99344C2.73314 20.4173 2.60298 20.1521 2.60298 19.887V17.2354C1.17134 17.2354 0 16.0421 0 14.5838V2.65158C0 1.19321 1.17134 0 2.60298 0ZM2.60316 11.2696C2.60316 11.6673 2.86346 11.9325 3.25391 11.9325H4.5554C5.5966 11.9325 6.50764 11.0044 6.50764 9.94376C6.50764 8.88312 5.5966 7.95505 4.5554 7.95505C4.16496 7.95505 3.90465 7.68991 3.90465 7.29218C3.90465 6.89441 4.16496 6.62927 4.5554 6.62927H5.85689C6.24733 6.62927 6.50764 6.36411 6.50764 5.96637C6.50764 5.56863 6.24733 5.30347 5.85689 5.30347H4.5554C3.51421 5.30347 2.60316 6.23154 2.60316 7.29218C2.60316 8.35281 3.51421 9.28085 4.5554 9.28085C4.94585 9.28085 5.20613 9.54602 5.20613 9.94376C5.20613 10.3415 4.94585 10.6067 4.5554 10.6067H3.25391C2.86346 10.6067 2.60316 10.8718 2.60316 11.2696ZM14.9678 11.9325H13.6664C13.2759 11.9325 13.0156 11.6673 13.0156 11.2696C13.0156 10.8718 13.2759 10.6067 13.6664 10.6067H14.9678C15.3583 10.6067 15.6186 10.3415 15.6186 9.94376C15.6186 9.54602 15.3583 9.28085 14.9678 9.28085C13.9267 9.28085 13.0156 8.35281 13.0156 7.29218C13.0156 6.23154 13.9267 5.30347 14.9678 5.30347H16.2693C16.6598 5.30347 16.9201 5.56863 16.9201 5.96637C16.9201 6.36411 16.6598 6.62927 16.2693 6.62927H14.9678C14.5774 6.62927 14.3171 6.89441 14.3171 7.29218C14.3171 7.68991 14.5774 7.95505 14.9678 7.95505C16.009 7.95505 16.9201 8.88312 16.9201 9.94376C16.9201 11.0044 16.009 11.9325 14.9678 11.9325ZM10.4126 11.2697C10.4126 11.6674 10.6729 11.9326 11.0633 11.9326C11.4538 11.9326 11.7141 11.6674 11.8442 11.2697V5.96649C11.8442 5.70135 11.5839 5.43619 11.3236 5.30362C10.9332 5.30362 10.6729 5.43619 10.5427 5.70135L9.76186 7.15973L8.98094 5.70135C8.85081 5.43619 8.46034 5.17102 8.20006 5.30362C7.93977 5.43619 7.67946 5.70135 7.67946 5.96649V11.2697C7.67946 11.6674 7.93977 11.9326 8.33022 11.9326C8.72066 11.9326 8.98094 11.6674 8.98094 11.2697V8.75067L9.1111 8.88327C9.37138 9.28101 10.0221 9.28101 10.2825 8.88327L10.4126 8.75067V11.2697Z\" transform=\"translate(9.67801 10.4601)\" fill=\"white\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"#202020","icon_rgb_color":"32,32,32","channel_type":"SMS","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"","wp_popup_headline":"","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"sms:+971501047667","mobile_target":"","desktop_target":"","target":"","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"c4d17440a9","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""},{"channel":"Linkedin","value":"https:\/\/www.linkedin.com\/in\/spearhead-properties-uae-4504a5352\/","hover_text":"Linkedin","chatway_position":"","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.5\" cy=\"19.5\" r=\"19.5\" fill=\"#0077b5\"\/><path id=\"LinkedIn_color\" d=\"M18,20.1v6.655H14.142V20.549c0-1.56-.558-2.624-1.954-2.624a2.111,2.111,0,0,0-1.98,1.411,2.64,2.64,0,0,0-.128.941v6.481H6.221s.052-10.516,0-11.606H10.08V16.8c-.008.012-.018.026-.025.037h.025V16.8a3.832,3.832,0,0,1,3.478-1.918C16.1,14.88,18,16.539,18,20.1ZM2.184,9.558a2.011,2.011,0,1,0-.051,4.011h.026a2.012,2.012,0,1,0,.025-4.011ZM.229,26.758H4.087V15.152H.229Z\" transform=\"translate(11 1.442)\" fill=\"#fff\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"#202020","icon_rgb_color":"32,32,32","channel_type":"Linkedin","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"","wp_popup_headline":"","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"company","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"https:\/\/www.linkedin.com\/company\/https:\/\/www.linkedin.com\/in\/spearhead-properties-uae-4504a5352\/","mobile_target":"_blank","desktop_target":"_blank","target":"_blank","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"c4d17440a9","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""},{"channel":"Google_Maps","value":"https:\/\/maps.app.goo.gl\/Y3ELisgPpe9oBPLX8","hover_text":"Google Maps","chatway_position":"","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#37AA66\"\/><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M0 8.06381C0 3.68631 3.68633 0 8.06383 0C12.4413 0 16.1276 3.68631 16.1276 8.06381C16.1276 12.2109 9.67659 19.5835 8.9854 20.2747C8.755 20.5051 8.29422 20.7355 8.06383 20.7355C7.83344 20.7355 7.37263 20.5051 7.14224 20.2747C6.45107 19.5835 0 12.2109 0 8.06381ZM11.5203 8.06378C11.5203 9.97244 9.97302 11.5197 8.06436 11.5197C6.15572 11.5197 4.60844 9.97244 4.60844 8.06378C4.60844 6.15515 6.15572 4.60788 8.06436 4.60788C9.97302 4.60788 11.5203 6.15515 11.5203 8.06378Z\" transform=\"translate(11.3764 9.07178)\" fill=\"white\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"#202020","icon_rgb_color":"32,32,32","channel_type":"Google_Maps","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"","wp_popup_headline":"","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"https:\/\/maps.app.goo.gl\/Y3ELisgPpe9oBPLX8","mobile_target":"_blank","desktop_target":"_blank","target":"_blank","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"c4d17440a9","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""},{"channel":"Twitter","value":"SpearheadReUAE","hover_text":"Twitter","chatway_position":"","svg_icon":"<svg width=\"512\" height=\"512\" viewBox=\"0 0 512 512\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle cx=\"256\" cy=\"256\" r=\"256\" fill=\"#000000\"class=\"color-element\"\/><path d=\"M108.72 117L223.002 269.781L108 394H133.884L234.571 285.242L315.92 394H404L283.285 232.626L390.33 117H364.446L271.721 217.16L196.8 117H108.72ZM146.785 136.062H187.248L365.931 374.938H325.467L146.785 136.062Z\" fill=\"white\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"#000000","icon_rgb_color":"0,0,0","channel_type":"Twitter","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"","wp_popup_headline":"","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"https:\/\/twitter.com\/SpearheadReUAE","mobile_target":"_blank","desktop_target":"_blank","target":"_blank","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"c4d17440a9","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""}]}],"ajax_url":"http:\/\/spearheadproperties.local\/wp-admin\/admin-ajax.php","data_analytics_settings":"on","page_id":"1","product":{"title":"","sku":"","price":"","regPrice":"","discount":""},"lang":{"whatsapp_label":"WhatsApp Message","whatsapp_button":"Send WhatsApp Message","hide_whatsapp_form":"Hide WhatsApp Form","emoji_picker":"Show Emojis"},"has_chatway":""};
/* ]]> */
</script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/plugins/chaty-pro/js/cht-front-script.min.js?ver=3.3.21756708733" id="chaty-js" data-wp-strategy="defer"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/plugins/chaty-pro/js/picmo-umd.min.js?ver=3.3.2" id="chaty-picmo-js-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/jquery/ui/accordion.min.js?ver=1.13.3" id="jquery-ui-accordion-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/jquery/ui/tabs.min.js?ver=1.13.3" id="jquery-ui-tabs-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/doubletaptogo.js?ver=6.8.2" id="doubleTapToGo-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/modernizr.min.js?ver=6.8.2" id="modernizr-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.appear.js?ver=6.8.2" id="appear-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/counter.js?ver=6.8.2" id="counter-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/easypiechart.js?ver=6.8.2" id="easyPieChart-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/mixitup.js?ver=6.8.2" id="mixItUp-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.prettyPhoto.js?ver=6.8.2" id="prettyphoto-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.fitvids.js?ver=6.8.2" id="fitvids-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.flexslider-min.js?ver=6.8.2" id="flexslider-js"></script>
<script type="text/javascript" id="mediaelement-core-js-before">
/* <![CDATA[ */
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
/* ]]> */
</script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.17" id="mediaelement-core-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=6.8.2" id="mediaelement-migrate-js"></script>
<script type="text/javascript" id="mediaelement-js-extra">
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive","audioShortcodeLibrary":"mediaelement","videoShortcodeLibrary":"mediaelement"};
/* ]]> */
</script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=6.8.2" id="wp-mediaelement-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/infinitescroll.min.js?ver=6.8.2" id="infiniteScroll-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.waitforimages.js?ver=6.8.2" id="waitforimages-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-includes/js/jquery/jquery.form.min.js?ver=4.3.0" id="jquery-form-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/waypoints.min.js?ver=6.8.2" id="waypoints-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jplayer.min.js?ver=6.8.2" id="jplayer-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/bootstrap.carousel.js?ver=6.8.2" id="bootstrapCarousel-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/skrollr.js?ver=6.8.2" id="skrollr-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/Chart.min.js?ver=6.8.2" id="charts-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.easing.1.3.js?ver=6.8.2" id="easing-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/abstractBaseClass.js?ver=6.8.2" id="abstractBaseClass-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.countdown.js?ver=6.8.2" id="countdown-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.multiscroll.min.js?ver=6.8.2" id="multiscroll-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.justifiedGallery.min.js?ver=6.8.2" id="justifiedGallery-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/bigtext.js?ver=6.8.2" id="bigtext-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.sticky-kit.min.js?ver=6.8.2" id="stickyKit-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/owl.carousel.min.js?ver=6.8.2" id="owlCarousel-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/typed.js?ver=6.8.2" id="typed-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.carouFredSel-6.2.1.min.js?ver=6.8.2" id="carouFredSel-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/lemmon-slider.min.js?ver=6.8.2" id="lemmonSlider-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.fullPage.min.js?ver=6.8.2" id="one_page_scroll-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.mousewheel.min.js?ver=6.8.2" id="mousewheel-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.touchSwipe.min.js?ver=6.8.2" id="touchSwipe-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.isotope.min.js?ver=6.8.2" id="isotope-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/packery-mode.pkgd.min.js?ver=6.8.2" id="packery-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.stretch.js?ver=6.8.2" id="stretch-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/imagesloaded.js?ver=6.8.2" id="imagesLoaded-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/rangeslider.min.js?ver=6.8.2" id="rangeSlider-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.event.move.js?ver=6.8.2" id="eventMove-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/jquery.twentytwenty.js?ver=6.8.2" id="twentytwenty-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/plugins/elementor/assets/lib/swiper/v8/swiper.min.js?ver=8.4.5" id="swiper-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/default_dynamic.js?ver=1756708981" id="bridge-default-dynamic-js"></script>
<script type="text/javascript" id="bridge-default-js-extra">
/* <![CDATA[ */
var QodeAdminAjax = {"ajaxurl":"http:\/\/spearheadproperties.local\/wp-admin\/admin-ajax.php"};
var qodeGlobalVars = {"vars":{"qodeAddingToCartLabel":"Adding to Cart...","page_scroll_amount_for_sticky":""}};
/* ]]> */
</script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/default.min.js?ver=6.8.2" id="bridge-default-js"></script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.6.0" id="wpb_composer_front_js-js"></script>
<script type="text/javascript" id="qode-like-js-extra">
/* <![CDATA[ */
var qodeLike = {"ajaxurl":"http:\/\/spearheadproperties.local\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="http://spearheadproperties.local/wp-content/themes/bridge/js/plugins/qode-like.min.js?ver=6.8.2" id="qode-like-js"></script>
		<style>
			.unlimited-elements-background-overlay{
				position:absolute;
				top:0px;
				left:0px;
				width:100%;
				height:100%;
				z-index:0;
			}

			.unlimited-elements-background-overlay.uc-bg-front{
				z-index:999;
			}
		</style>

		<script type='text/javascript'>

			jQuery(document).ready(function(){

				function ucBackgroundOverlayPutStart(){

					var objBG = jQuery(".unlimited-elements-background-overlay").not(".uc-bg-attached");

					if(objBG.length == 0)
						return(false);

					objBG.each(function(index, bgElement){

						var objBgElement = jQuery(bgElement);

						var targetID = objBgElement.data("forid");

						var location = objBgElement.data("location");

						switch(location){
							case "body":
							case "body_front":
								var objTarget = jQuery("body");
							break;
							case "layout":
							case "layout_front":
								var objLayout = jQuery("*[data-id=\""+targetID+"\"]");
								var objTarget = objLayout.parents(".elementor");
								if(objTarget.length > 1)
									objTarget = jQuery(objTarget[0]);
							break;
							default:
								var objTarget = jQuery("*[data-id=\""+targetID+"\"]");
							break;
						}


						if(objTarget.length == 0)
							return(true);

						var objVideoContainer = objTarget.children(".elementor-background-video-container");

						if(objVideoContainer.length == 1)
							objBgElement.detach().insertAfter(objVideoContainer).show();
						else
							objBgElement.detach().prependTo(objTarget).show();


						var objTemplate = objBgElement.children("template");

						if(objTemplate.length){
							
					        var clonedContent = objTemplate[0].content.cloneNode(true);

					    	var objScripts = jQuery(clonedContent).find("script");
					    	if(objScripts.length)
					    		objScripts.attr("type","text/javascript");
					        
					        objBgElement.append(clonedContent);
							
							objTemplate.remove();
						}

						objBgElement.trigger("bg_attached");
						objBgElement.addClass("uc-bg-attached");

					});
				}

				ucBackgroundOverlayPutStart();

				jQuery( document ).on( 'elementor/popup/show', ucBackgroundOverlayPutStart);
				jQuery( "body" ).on( 'uc_dom_updated', ucBackgroundOverlayPutStart);

			});


		</script>
		</body>
</html>